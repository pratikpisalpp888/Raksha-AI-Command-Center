from .analyzer import IntentAnalyzer
